# VMP-Bot - Telegram bot for society management

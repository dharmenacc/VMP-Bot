# Handles SQLite DB initialization and access

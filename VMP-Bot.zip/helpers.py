# Helper functions for session, language, etc.

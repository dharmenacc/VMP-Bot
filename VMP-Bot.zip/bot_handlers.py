# Telegram bot command and message handlers

# Entry point for the Telegram bot
